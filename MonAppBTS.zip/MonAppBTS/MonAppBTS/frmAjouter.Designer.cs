﻿namespace MonAppBTS
{
    partial class frmAjouter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAjouter));
            this.tabAjouter = new System.Windows.Forms.TabControl();
            this.tabAjouterEleve = new System.Windows.Forms.TabPage();
            this.lblAnnee = new System.Windows.Forms.Label();
            this.lblNumero = new System.Windows.Forms.Label();
            this.lblCursus = new System.Windows.Forms.Label();
            this.btnAjouterClasse = new System.Windows.Forms.Button();
            this.textAnnee = new System.Windows.Forms.TextBox();
            this.textNumero = new System.Windows.Forms.TextBox();
            this.textCursus = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cbxClasseEleve = new System.Windows.Forms.ComboBox();
            this.textCPEleve = new System.Windows.Forms.TextBox();
            this.textVilleEleve = new System.Windows.Forms.TextBox();
            this.textAdresseEleve = new System.Windows.Forms.TextBox();
            this.textNomEleve = new System.Windows.Forms.TextBox();
            this.textPrenom = new System.Windows.Forms.TextBox();
            this.lblClasse = new System.Windows.Forms.Label();
            this.lblCP = new System.Windows.Forms.Label();
            this.txtVille = new System.Windows.Forms.Label();
            this.lblAdresse = new System.Windows.Forms.Label();
            this.textNom = new System.Windows.Forms.Label();
            this.btnAjouterEleve = new System.Windows.Forms.Button();
            this.lblPrenom = new System.Windows.Forms.Label();
            this.elevesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ecoleDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ecoleDataSet = new MonAppBTS.EcoleDataSet();
            this.elevesTableAdapter = new MonAppBTS.EcoleDataSetTableAdapters.ElevesTableAdapter();
            this.classesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.classesTableAdapter = new MonAppBTS.EcoleDataSetTableAdapters.ClassesTableAdapter();
            this.btnAccueil = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tabAjouter.SuspendLayout();
            this.tabAjouterEleve.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elevesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ecoleDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ecoleDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.classesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabAjouter
            // 
            this.tabAjouter.Controls.Add(this.tabAjouterEleve);
            this.tabAjouter.Controls.Add(this.tabPage2);
            this.tabAjouter.Location = new System.Drawing.Point(28, 99);
            this.tabAjouter.Name = "tabAjouter";
            this.tabAjouter.SelectedIndex = 0;
            this.tabAjouter.Size = new System.Drawing.Size(745, 326);
            this.tabAjouter.TabIndex = 0;
            // 
            // tabAjouterEleve
            // 
            this.tabAjouterEleve.Controls.Add(this.lblAnnee);
            this.tabAjouterEleve.Controls.Add(this.lblNumero);
            this.tabAjouterEleve.Controls.Add(this.lblCursus);
            this.tabAjouterEleve.Controls.Add(this.btnAjouterClasse);
            this.tabAjouterEleve.Controls.Add(this.textAnnee);
            this.tabAjouterEleve.Controls.Add(this.textNumero);
            this.tabAjouterEleve.Controls.Add(this.textCursus);
            this.tabAjouterEleve.Location = new System.Drawing.Point(4, 25);
            this.tabAjouterEleve.Name = "tabAjouterEleve";
            this.tabAjouterEleve.Padding = new System.Windows.Forms.Padding(3);
            this.tabAjouterEleve.Size = new System.Drawing.Size(737, 297);
            this.tabAjouterEleve.TabIndex = 0;
            this.tabAjouterEleve.Text = "Classe";
            this.tabAjouterEleve.UseVisualStyleBackColor = true;
            // 
            // lblAnnee
            // 
            this.lblAnnee.AutoSize = true;
            this.lblAnnee.Location = new System.Drawing.Point(218, 149);
            this.lblAnnee.Name = "lblAnnee";
            this.lblAnnee.Size = new System.Drawing.Size(49, 17);
            this.lblAnnee.TabIndex = 6;
            this.lblAnnee.Text = "Année";
            // 
            // lblNumero
            // 
            this.lblNumero.AutoSize = true;
            this.lblNumero.Location = new System.Drawing.Point(218, 101);
            this.lblNumero.Name = "lblNumero";
            this.lblNumero.Size = new System.Drawing.Size(58, 17);
            this.lblNumero.TabIndex = 5;
            this.lblNumero.Text = "Numéro";
            // 
            // lblCursus
            // 
            this.lblCursus.AutoSize = true;
            this.lblCursus.Location = new System.Drawing.Point(218, 56);
            this.lblCursus.Name = "lblCursus";
            this.lblCursus.Size = new System.Drawing.Size(107, 17);
            this.lblCursus.TabIndex = 4;
            this.lblCursus.Text = "Cursus Scolaire";
            // 
            // btnAjouterClasse
            // 
            this.btnAjouterClasse.Location = new System.Drawing.Point(258, 199);
            this.btnAjouterClasse.Name = "btnAjouterClasse";
            this.btnAjouterClasse.Size = new System.Drawing.Size(161, 38);
            this.btnAjouterClasse.TabIndex = 3;
            this.btnAjouterClasse.Text = "Ajouter une classe";
            this.btnAjouterClasse.UseVisualStyleBackColor = true;
            this.btnAjouterClasse.Click += new System.EventHandler(this.btnAjouterClasse_Click);
            // 
            // textAnnee
            // 
            this.textAnnee.Location = new System.Drawing.Point(421, 149);
            this.textAnnee.Name = "textAnnee";
            this.textAnnee.Size = new System.Drawing.Size(100, 22);
            this.textAnnee.TabIndex = 2;
            // 
            // textNumero
            // 
            this.textNumero.Location = new System.Drawing.Point(421, 101);
            this.textNumero.Name = "textNumero";
            this.textNumero.Size = new System.Drawing.Size(100, 22);
            this.textNumero.TabIndex = 1;
            // 
            // textCursus
            // 
            this.textCursus.Location = new System.Drawing.Point(421, 52);
            this.textCursus.Name = "textCursus";
            this.textCursus.Size = new System.Drawing.Size(100, 22);
            this.textCursus.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.cbxClasseEleve);
            this.tabPage2.Controls.Add(this.textCPEleve);
            this.tabPage2.Controls.Add(this.textVilleEleve);
            this.tabPage2.Controls.Add(this.textAdresseEleve);
            this.tabPage2.Controls.Add(this.textNomEleve);
            this.tabPage2.Controls.Add(this.textPrenom);
            this.tabPage2.Controls.Add(this.lblClasse);
            this.tabPage2.Controls.Add(this.lblCP);
            this.tabPage2.Controls.Add(this.txtVille);
            this.tabPage2.Controls.Add(this.lblAdresse);
            this.tabPage2.Controls.Add(this.textNom);
            this.tabPage2.Controls.Add(this.btnAjouterEleve);
            this.tabPage2.Controls.Add(this.lblPrenom);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(737, 297);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Elèves";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // cbxClasseEleve
            // 
            this.cbxClasseEleve.FormattingEnabled = true;
            this.cbxClasseEleve.Location = new System.Drawing.Point(573, 120);
            this.cbxClasseEleve.Name = "cbxClasseEleve";
            this.cbxClasseEleve.Size = new System.Drawing.Size(121, 24);
            this.cbxClasseEleve.TabIndex = 12;
            // 
            // textCPEleve
            // 
            this.textCPEleve.Location = new System.Drawing.Point(573, 45);
            this.textCPEleve.Name = "textCPEleve";
            this.textCPEleve.Size = new System.Drawing.Size(100, 22);
            this.textCPEleve.TabIndex = 11;
            // 
            // textVilleEleve
            // 
            this.textVilleEleve.Location = new System.Drawing.Point(347, 123);
            this.textVilleEleve.Name = "textVilleEleve";
            this.textVilleEleve.Size = new System.Drawing.Size(100, 22);
            this.textVilleEleve.TabIndex = 10;
            // 
            // textAdresseEleve
            // 
            this.textAdresseEleve.Location = new System.Drawing.Point(347, 46);
            this.textAdresseEleve.Name = "textAdresseEleve";
            this.textAdresseEleve.Size = new System.Drawing.Size(100, 22);
            this.textAdresseEleve.TabIndex = 9;
            // 
            // textNomEleve
            // 
            this.textNomEleve.Location = new System.Drawing.Point(123, 124);
            this.textNomEleve.Name = "textNomEleve";
            this.textNomEleve.Size = new System.Drawing.Size(100, 22);
            this.textNomEleve.TabIndex = 8;
            // 
            // textPrenom
            // 
            this.textPrenom.Location = new System.Drawing.Point(123, 46);
            this.textPrenom.Name = "textPrenom";
            this.textPrenom.Size = new System.Drawing.Size(100, 22);
            this.textPrenom.TabIndex = 7;
            // 
            // lblClasse
            // 
            this.lblClasse.AutoSize = true;
            this.lblClasse.Location = new System.Drawing.Point(511, 123);
            this.lblClasse.Name = "lblClasse";
            this.lblClasse.Size = new System.Drawing.Size(50, 17);
            this.lblClasse.TabIndex = 6;
            this.lblClasse.Text = "Classe";
            // 
            // lblCP
            // 
            this.lblCP.AutoSize = true;
            this.lblCP.Location = new System.Drawing.Point(477, 45);
            this.lblCP.Name = "lblCP";
            this.lblCP.Size = new System.Drawing.Size(84, 17);
            this.lblCP.TabIndex = 5;
            this.lblCP.Text = "Code Postal";
            // 
            // txtVille
            // 
            this.txtVille.AutoSize = true;
            this.txtVille.Location = new System.Drawing.Point(307, 124);
            this.txtVille.Name = "txtVille";
            this.txtVille.Size = new System.Drawing.Size(34, 17);
            this.txtVille.TabIndex = 4;
            this.txtVille.Text = "Ville";
            // 
            // lblAdresse
            // 
            this.lblAdresse.AutoSize = true;
            this.lblAdresse.Location = new System.Drawing.Point(283, 46);
            this.lblAdresse.Name = "lblAdresse";
            this.lblAdresse.Size = new System.Drawing.Size(60, 17);
            this.lblAdresse.TabIndex = 3;
            this.lblAdresse.Text = "Adresse";
            // 
            // textNom
            // 
            this.textNom.AutoSize = true;
            this.textNom.Location = new System.Drawing.Point(80, 123);
            this.textNom.Name = "textNom";
            this.textNom.Size = new System.Drawing.Size(37, 17);
            this.textNom.TabIndex = 2;
            this.textNom.Text = "Nom";
            // 
            // btnAjouterEleve
            // 
            this.btnAjouterEleve.Location = new System.Drawing.Point(286, 202);
            this.btnAjouterEleve.Name = "btnAjouterEleve";
            this.btnAjouterEleve.Size = new System.Drawing.Size(171, 42);
            this.btnAjouterEleve.TabIndex = 1;
            this.btnAjouterEleve.Text = "Ajouter un élève";
            this.btnAjouterEleve.UseVisualStyleBackColor = true;
            this.btnAjouterEleve.Click += new System.EventHandler(this.btnAjouterEleve_Click);
            // 
            // lblPrenom
            // 
            this.lblPrenom.AutoSize = true;
            this.lblPrenom.Location = new System.Drawing.Point(60, 46);
            this.lblPrenom.Name = "lblPrenom";
            this.lblPrenom.Size = new System.Drawing.Size(57, 17);
            this.lblPrenom.TabIndex = 0;
            this.lblPrenom.Text = "Prénom";
            // 
            // elevesBindingSource
            // 
            this.elevesBindingSource.DataMember = "Eleves";
            this.elevesBindingSource.DataSource = this.ecoleDataSetBindingSource;
            // 
            // ecoleDataSetBindingSource
            // 
            this.ecoleDataSetBindingSource.DataSource = this.ecoleDataSet;
            this.ecoleDataSetBindingSource.Position = 0;
            // 
            // ecoleDataSet
            // 
            this.ecoleDataSet.DataSetName = "EcoleDataSet";
            this.ecoleDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // elevesTableAdapter
            // 
            this.elevesTableAdapter.ClearBeforeFill = true;
            // 
            // classesBindingSource
            // 
            this.classesBindingSource.DataMember = "Classes";
            this.classesBindingSource.DataSource = this.ecoleDataSetBindingSource;
            // 
            // classesTableAdapter
            // 
            this.classesTableAdapter.ClearBeforeFill = true;
            // 
            // btnAccueil
            // 
            this.btnAccueil.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAccueil.Location = new System.Drawing.Point(28, 12);
            this.btnAccueil.Name = "btnAccueil";
            this.btnAccueil.Size = new System.Drawing.Size(108, 81);
            this.btnAccueil.TabIndex = 1;
            this.btnAccueil.Text = "Retour Accueil";
            this.btnAccueil.UseVisualStyleBackColor = true;
            this.btnAccueil.Click += new System.EventHandler(this.btnAccueil_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(153, 6);
            this.label1.MaximumSize = new System.Drawing.Size(600, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(591, 90);
            this.label1.TabIndex = 2;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // frmAjouter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAccueil);
            this.Controls.Add(this.tabAjouter);
            this.Name = "frmAjouter";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Ajouter des classes ou des élèves";
            this.Load += new System.EventHandler(this.frmAjouter_Load);
            this.tabAjouter.ResumeLayout(false);
            this.tabAjouterEleve.ResumeLayout(false);
            this.tabAjouterEleve.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.elevesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ecoleDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ecoleDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.classesBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabAjouter;
        private System.Windows.Forms.TabPage tabAjouterEleve;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblAnnee;
        private System.Windows.Forms.Label lblNumero;
        private System.Windows.Forms.Label lblCursus;
        private System.Windows.Forms.Button btnAjouterClasse;
        private System.Windows.Forms.TextBox textAnnee;
        private System.Windows.Forms.TextBox textNumero;
        private System.Windows.Forms.TextBox textCursus;
        private System.Windows.Forms.TextBox textCPEleve;
        private System.Windows.Forms.TextBox textVilleEleve;
        private System.Windows.Forms.TextBox textAdresseEleve;
        private System.Windows.Forms.TextBox textNomEleve;
        private System.Windows.Forms.TextBox textPrenom;
        private System.Windows.Forms.Label lblClasse;
        private System.Windows.Forms.Label lblCP;
        private System.Windows.Forms.Label txtVille;
        private System.Windows.Forms.Label lblAdresse;
        private System.Windows.Forms.Label textNom;
        private System.Windows.Forms.Button btnAjouterEleve;
        private System.Windows.Forms.Label lblPrenom;
        private System.Windows.Forms.ComboBox cbxClasseEleve;
        private System.Windows.Forms.BindingSource ecoleDataSetBindingSource;
        private EcoleDataSet ecoleDataSet;
        private System.Windows.Forms.BindingSource elevesBindingSource;
        private EcoleDataSetTableAdapters.ElevesTableAdapter elevesTableAdapter;
        private System.Windows.Forms.BindingSource classesBindingSource;
        private EcoleDataSetTableAdapters.ClassesTableAdapter classesTableAdapter;
        private System.Windows.Forms.Button btnAccueil;
        private System.Windows.Forms.Label label1;
    }
}