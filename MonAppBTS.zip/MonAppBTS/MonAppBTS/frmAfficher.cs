﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MonAppBTS
{
    public partial class frmAfficher : Form
    {
        SqlConnection sqlcon = new SqlConnection(@"Data Source=DESKTOP-AURVH6M\MSSQLSERVER2;Initial Catalog=Ecole;User ID=sa;Password=azertyuiop");
        SqlCommand cmd;
        DataTable dt;
        SqlDataAdapter da;
        DataSet ds;

        public frmAfficher()
        {
            InitializeComponent();


        }



        private void btnAfficherClasse_Click(object sender, EventArgs e)
        {
            listView1.Columns.Add("id_classe", 70);
            listView1.Columns.Add("Cursus", 70, HorizontalAlignment.Center);
            listView1.Columns.Add("Numero", 70, HorizontalAlignment.Center);
            listView1.Columns.Add("Année", 70, HorizontalAlignment.Right);
            listView1.View = View.Details;

            sqlcon.Open();
            cmd = new SqlCommand("select * from Classes order by cursus", sqlcon);
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds, "testTable");
            sqlcon.Close();

            dt = ds.Tables["testTable"];
            int i;
            for (i = 0; i <= dt.Rows.Count - 1; i++)
            {
                listView1.Items.Add(dt.Rows[i].ItemArray[0].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i].ItemArray[1].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i].ItemArray[2].ToString());
                listView1.Items[i].SubItems.Add(dt.Rows[i].ItemArray[3].ToString());

            }
        }

        private void btnAfficherEleve_Click(object sender, EventArgs e)
        {
            listView2.Columns.Add("id_eleve", 70);
            listView2.Columns.Add("Prénom", 70, HorizontalAlignment.Center);
            listView2.Columns.Add("Nom", 70, HorizontalAlignment.Center);
            listView2.Columns.Add("Adresse", 70, HorizontalAlignment.Center);
            listView2.Columns.Add("Ville", 70, HorizontalAlignment.Center);
            listView2.Columns.Add("CP", 70, HorizontalAlignment.Center);
            listView2.Columns.Add("Cursus", 70, HorizontalAlignment.Center);
            listView2.Columns.Add("Numero", 70, HorizontalAlignment.Right);
            listView2.View = View.Details;

            sqlcon.Open();
            cmd = new SqlCommand("select id_eleve, prenom, nom, adresse, ville, CP, cursus, numero from Eleves inner join Classes on Eleves.id_classe = Classes.id_classe order by cursus", sqlcon);
            da = new SqlDataAdapter(cmd);
            ds = new DataSet();
            da.Fill(ds, "testTables");
            sqlcon.Close();


            dt = ds.Tables["testTables"];
            int i;
            for (i = 0; i <= dt.Rows.Count - 1; i++)
            {
                listView2.Items.Add(dt.Rows[i].ItemArray[0].ToString());
                listView2.Items[i].SubItems.Add(dt.Rows[i].ItemArray[1].ToString());
                listView2.Items[i].SubItems.Add(dt.Rows[i].ItemArray[2].ToString());
                listView2.Items[i].SubItems.Add(dt.Rows[i].ItemArray[3].ToString());
                listView2.Items[i].SubItems.Add(dt.Rows[i].ItemArray[4].ToString());
                listView2.Items[i].SubItems.Add(dt.Rows[i].ItemArray[5].ToString());
                listView2.Items[i].SubItems.Add(dt.Rows[i].ItemArray[6].ToString());
                listView2.Items[i].SubItems.Add(dt.Rows[i].ItemArray[7].ToString());


            }
        }

        private void btnSupprimerClasse_Click(object sender, EventArgs e)
        {

            String id_classe = listView1.SelectedItems[0].SubItems[0].Text;
            Int16.Parse(id_classe);

            string del = "DELETE FROM Classes WHERE id_classe =" + id_classe + "";
            cmd = new SqlCommand(del, sqlcon);

            try
            {
                sqlcon.Open();
                
                da = new SqlDataAdapter(cmd);
                da.DeleteCommand = sqlcon.CreateCommand();
                da.DeleteCommand.CommandText = del;

               
                if (MessageBox.Show("Etes-vous certain de vouloir supprimer cette classe", "Confirmation de supression", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
                {
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        listView1.Items.Clear();
                        MessageBox.Show("La classe a bien été supprimée");
                    }
                }
                sqlcon.Close();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                sqlcon.Close();
            }
        }

        private void btnSupprimerEleve_Click(object sender, EventArgs e)
        {
            String id_eleve = listView2.SelectedItems[0].SubItems[0].Text;
            Int16.Parse(id_eleve);

            string del = "DELETE FROM Eleves WHERE id_eleve =" + id_eleve + "";
            cmd = new SqlCommand(del, sqlcon);

            try
            {
                sqlcon.Open();

                da = new SqlDataAdapter(cmd);
                da.DeleteCommand = sqlcon.CreateCommand();
                da.DeleteCommand.CommandText = del;


                if (MessageBox.Show("Etes-vous certain de vouloir supprimer cet élève", "Confiration de suppresion", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
                {
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        listView2.Items.Clear();
                        MessageBox.Show("L'élève a bien été supprimée");
                    }
                }
                sqlcon.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                sqlcon.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmMain objFrmMain = new frmMain();
            this.Hide();
            objFrmMain.Show();
        }
    }
    
}

