﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MonAppBTS
{
    public partial class frmAjouter : Form
    {
        public frmAjouter()
        {
            InitializeComponent();
        }

        SqlConnection sqlcon = new SqlConnection(@"Data Source=DESKTOP-AURVH6M\MSSQLSERVER2;Initial Catalog=Ecole;User ID=sa;Password=azertyuiop");
        SqlCommand cmd;

        private void btnAjouterClasse_Click(object sender, EventArgs e)
        {
            sqlcon.Open();
            SqlCommand cmd = new SqlCommand("insert into Classes (cursus, numero, annee) values ('" + textCursus.Text + "', '" + textNumero.Text + "', '" + textAnnee.Text + "')", sqlcon);
            cmd.ExecuteNonQuery();
            MessageBox.Show("La classe a bien été créé !");
            sqlcon.Close();

        }

        private void btnAjouterEleve_Click(object sender, EventArgs e)
        {
            sqlcon.Open();
            SqlCommand cmd = new SqlCommand("insert into Eleves (prenom, nom, adresse, ville, cp, id_classe) values ('" + textPrenom.Text + "', '" + textNomEleve.Text + "', '" + textAdresseEleve.Text + "' , '" + textVilleEleve.Text + "' , '" + textCPEleve.Text + "' , '" + cbxClasseEleve.ValueMember + "')", sqlcon);
            cmd.ExecuteNonQuery();
            MessageBox.Show("L'élève a bien été créé !");
            sqlcon.Close();
        }

        private void frmAjouter_Load(object sender, EventArgs e)
        {
            reqCbxClasse();
        }

        public void reqCbxClasse()
        {
            sqlcon.Open();
            string req = "select * from Classes";
            SqlCommand cmd = new SqlCommand(req, sqlcon);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                cbxClasseEleve.Items.Add(dr["cursus"].ToString() + " " + dr["numero"].ToString() + " " + dr["annee"].ToString());
                cbxClasseEleve.DisplayMember = (dr["cursus"].ToString());
                cbxClasseEleve.ValueMember = (dr["id_classe"].ToString());
            }
            sqlcon.Close();
        }

        private void btnAccueil_Click(object sender, EventArgs e)
        {
            frmMain objFrmMain = new frmMain();
            this.Hide();
            objFrmMain.Show();
        }
    }
}
