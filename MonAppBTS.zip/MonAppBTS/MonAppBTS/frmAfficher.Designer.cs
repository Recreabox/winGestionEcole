﻿namespace MonAppBTS
{
    partial class frmAfficher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAfficher));
            this.tabAfficher = new System.Windows.Forms.TabControl();
            this.tabAfficherClasse = new System.Windows.Forms.TabPage();
            this.btnAfficherClasse = new System.Windows.Forms.Button();
            this.tabAfficherEleve = new System.Windows.Forms.TabPage();
            this.listView2 = new System.Windows.Forms.ListView();
            this.listView1 = new System.Windows.Forms.ListView();
            this.btnAfficherEleve = new System.Windows.Forms.Button();
            this.btnSupprimerClasse = new System.Windows.Forms.Button();
            this.btnSupprimerEleve = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lblInfoAfficher = new System.Windows.Forms.Label();
            this.tabAfficher.SuspendLayout();
            this.tabAfficherClasse.SuspendLayout();
            this.tabAfficherEleve.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabAfficher
            // 
            this.tabAfficher.Controls.Add(this.tabAfficherClasse);
            this.tabAfficher.Controls.Add(this.tabAfficherEleve);
            this.tabAfficher.Location = new System.Drawing.Point(12, 95);
            this.tabAfficher.Name = "tabAfficher";
            this.tabAfficher.SelectedIndex = 0;
            this.tabAfficher.Size = new System.Drawing.Size(776, 343);
            this.tabAfficher.TabIndex = 0;
            // 
            // tabAfficherClasse
            // 
            this.tabAfficherClasse.Controls.Add(this.btnSupprimerClasse);
            this.tabAfficherClasse.Controls.Add(this.listView1);
            this.tabAfficherClasse.Controls.Add(this.btnAfficherClasse);
            this.tabAfficherClasse.Location = new System.Drawing.Point(4, 25);
            this.tabAfficherClasse.Name = "tabAfficherClasse";
            this.tabAfficherClasse.Padding = new System.Windows.Forms.Padding(3);
            this.tabAfficherClasse.Size = new System.Drawing.Size(768, 314);
            this.tabAfficherClasse.TabIndex = 0;
            this.tabAfficherClasse.Text = "Classe";
            this.tabAfficherClasse.UseVisualStyleBackColor = true;
            // 
            // btnAfficherClasse
            // 
            this.btnAfficherClasse.Location = new System.Drawing.Point(285, 268);
            this.btnAfficherClasse.Name = "btnAfficherClasse";
            this.btnAfficherClasse.Size = new System.Drawing.Size(153, 40);
            this.btnAfficherClasse.TabIndex = 1;
            this.btnAfficherClasse.Text = "Afficher les classes";
            this.btnAfficherClasse.UseVisualStyleBackColor = true;
            this.btnAfficherClasse.Click += new System.EventHandler(this.btnAfficherClasse_Click);
            // 
            // tabAfficherEleve
            // 
            this.tabAfficherEleve.Controls.Add(this.btnSupprimerEleve);
            this.tabAfficherEleve.Controls.Add(this.btnAfficherEleve);
            this.tabAfficherEleve.Controls.Add(this.listView2);
            this.tabAfficherEleve.Location = new System.Drawing.Point(4, 25);
            this.tabAfficherEleve.Name = "tabAfficherEleve";
            this.tabAfficherEleve.Padding = new System.Windows.Forms.Padding(3);
            this.tabAfficherEleve.Size = new System.Drawing.Size(768, 314);
            this.tabAfficherEleve.TabIndex = 1;
            this.tabAfficherEleve.Text = "Elèves";
            this.tabAfficherEleve.UseVisualStyleBackColor = true;
            // 
            // listView2
            // 
            this.listView2.FullRowSelect = true;
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(6, 6);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(756, 254);
            this.listView2.TabIndex = 0;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.List;
            // 
            // listView1
            // 
            this.listView1.FullRowSelect = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(6, 6);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(756, 256);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // btnAfficherEleve
            // 
            this.btnAfficherEleve.Location = new System.Drawing.Point(216, 266);
            this.btnAfficherEleve.Name = "btnAfficherEleve";
            this.btnAfficherEleve.Size = new System.Drawing.Size(117, 42);
            this.btnAfficherEleve.TabIndex = 1;
            this.btnAfficherEleve.Text = "Afficher les élèves";
            this.btnAfficherEleve.UseVisualStyleBackColor = true;
            this.btnAfficherEleve.Click += new System.EventHandler(this.btnAfficherEleve_Click);
            // 
            // btnSupprimerClasse
            // 
            this.btnSupprimerClasse.Location = new System.Drawing.Point(455, 269);
            this.btnSupprimerClasse.Name = "btnSupprimerClasse";
            this.btnSupprimerClasse.Size = new System.Drawing.Size(138, 39);
            this.btnSupprimerClasse.TabIndex = 3;
            this.btnSupprimerClasse.Text = "Supprimer";
            this.btnSupprimerClasse.UseVisualStyleBackColor = true;
            this.btnSupprimerClasse.Click += new System.EventHandler(this.btnSupprimerClasse_Click);
            // 
            // btnSupprimerEleve
            // 
            this.btnSupprimerEleve.Location = new System.Drawing.Point(406, 266);
            this.btnSupprimerEleve.Name = "btnSupprimerEleve";
            this.btnSupprimerEleve.Size = new System.Drawing.Size(120, 41);
            this.btnSupprimerEleve.TabIndex = 2;
            this.btnSupprimerEleve.Text = "Supprimer";
            this.btnSupprimerEleve.UseVisualStyleBackColor = true;
            this.btnSupprimerEleve.Click += new System.EventHandler(this.btnSupprimerEleve_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(113, 76);
            this.button1.TabIndex = 1;
            this.button1.Text = "Retour Accueil";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblInfoAfficher
            // 
            this.lblInfoAfficher.AutoSize = true;
            this.lblInfoAfficher.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfoAfficher.Location = new System.Drawing.Point(152, 12);
            this.lblInfoAfficher.MaximumSize = new System.Drawing.Size(600, 0);
            this.lblInfoAfficher.Name = "lblInfoAfficher";
            this.lblInfoAfficher.Size = new System.Drawing.Size(597, 90);
            this.lblInfoAfficher.TabIndex = 2;
            this.lblInfoAfficher.Text = resources.GetString("lblInfoAfficher.Text");
            // 
            // frmAfficher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblInfoAfficher);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tabAfficher);
            this.Name = "frmAfficher";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Afficher";
            this.tabAfficher.ResumeLayout(false);
            this.tabAfficherClasse.ResumeLayout(false);
            this.tabAfficherEleve.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabAfficher;
        private System.Windows.Forms.TabPage tabAfficherClasse;
        private System.Windows.Forms.TabPage tabAfficherEleve;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.Button btnAfficherClasse;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button btnAfficherEleve;
        private System.Windows.Forms.Button btnSupprimerClasse;
        private System.Windows.Forms.Button btnSupprimerEleve;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblInfoAfficher;
    }
}